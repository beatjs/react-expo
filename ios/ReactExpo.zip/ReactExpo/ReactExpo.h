#import <Foundation/Foundation.h>

//! Project version number for ReactComponent.
FOUNDATION_EXPORT double ReactComponentVersionNumber;

//! Project version string for ReactComponent.
FOUNDATION_EXPORT const unsigned char ReactComponentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ReactComponent/PublicHeader.h>
