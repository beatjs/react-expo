//  Copyright © 2021 650 Industries. All rights reserved.

#import <EXUpdates/EXUpdatesDatabaseMigration.h>

NS_ASSUME_NONNULL_BEGIN

@interface EXUpdatesDatabaseMigration4To5 : NSObject <EXUpdatesDatabaseMigration>

@end

NS_ASSUME_NONNULL_END
