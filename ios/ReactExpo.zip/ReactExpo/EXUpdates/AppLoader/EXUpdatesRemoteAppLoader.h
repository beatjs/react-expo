//  Copyright © 2019 650 Industries. All rights reserved.

#import <EXUpdates/EXUpdatesAppLoader+Private.h>

NS_ASSUME_NONNULL_BEGIN

@interface EXUpdatesRemoteAppLoader : EXUpdatesAppLoader

@end

NS_ASSUME_NONNULL_END
