// Copyright 2018-present 650 Industries. All rights reserved.

#import <UMCore/UMSingletonModule.h>
#import <UMCore/UMLogHandler.h>

@interface UMReactLogHandler : UMSingletonModule <UMLogHandler>

@end
