// Copyright 2018-present 650 Industries. All rights reserved.

#import <UMCore/UMInternalModule.h>

@interface UMReactFontManager : NSObject <UMInternalModule>
@end
