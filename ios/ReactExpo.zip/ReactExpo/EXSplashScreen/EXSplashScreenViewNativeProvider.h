// Copyright © 2018 650 Industries. All rights reserved.

#import <Foundation/Foundation.h>
#import <EXSplashScreen/EXSplashScreenViewProvider.h>

NS_ASSUME_NONNULL_BEGIN

@interface EXSplashScreenViewNativeProvider : NSObject<EXSplashScreenViewProvider>

@end

NS_ASSUME_NONNULL_END
