// Copyright 2018-present 650 Industries. All rights reserved.

@protocol UMAppRecordInterface <NSObject>

- (void)invalidate;

@end
